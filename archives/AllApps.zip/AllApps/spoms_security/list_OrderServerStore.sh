#!/bin/bash
export KEYTOOL_JAVA17=../../java17/jdk-17.0.2/bin/keytool

STOREPASS="spoms2022"

echo ""
echo "****************************"
echo "[Order Server trusted store]"
echo "****************************"
echo ""
 
$KEYTOOL_JAVA17 -list -keystore OrderServer.jks -storepass ${STOREPASS} 2>/dev/null
#!/bin/bash

./list_AGVManager1Store.sh
./list_AGVManager2Store.sh
./list_AGVDigitalTwin1Store.sh
./list_AGVDigitalTwin12Store.sh
./list_AGVDigitalTwin13Store.sh
./list_OrderServerStore.sh
./list_ClientAppStore.sh
./list_HTTPServerStore.sh
./list_HTTPConsumerStore.sh

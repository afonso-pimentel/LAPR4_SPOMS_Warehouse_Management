#!/bin/bash

killall -9 java
#!/bin/bash

killall -9 java



#!/bin/bash

./HttpServer.sh & 2>&1 &
./OrderServer.sh & 2>&1 &   
./AgvManager1.sh & 2>&1 & 
sleep 5
./HttpConsumer.sh & 2>&1 &   



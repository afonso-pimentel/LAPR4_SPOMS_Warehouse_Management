#!/usr/bin/env bash
export JAVA=~/java17/jdk-17.0.2/bin/java

#REM set the class path,
#REM assumes the build was executed with maven copy-dependencies
export BASE_CP=./AllApps/AgvManager/AGVManager-1.4.0-SNAPSHOT.jar:./AllApps/dependencies/*;

#REM call the java VM, e.g, 
$JAVA -cp $BASE_CP AGVManager -p 8999 -id 2 -t AllApps/spoms_security/ -s spoms2022

#!/usr/bin/env bash
export JAVA=~/java17/jdk-17.0.2/bin/java

#REM set the class path,
#REM assumes the build was executed with maven copy-dependencies
export BASE_CP=./AllApps/HttpServer/HTTPServer-1.4.0-SNAPSHOT.jar:./AllApps/dependencies/*;

#REM call the java VM, e.g, 
$JAVA -cp $BASE_CP HttpConsumer -p 9990 -a localhost -p 9990 -k localhost -u 8081 -s spoms2022 -t AllApps/spoms_security/

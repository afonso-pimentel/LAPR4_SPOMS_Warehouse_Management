#!/usr/bin/env bash
export JAVA=~/java17/jdk-17.0.2/bin/java

#REM set the class path,
#REM assumes the build was executed with maven copy-dependencies
cd ./AllApps/HttpServer/

export BASE_CP=HTTPServer-1.4.0-SNAPSHOT.jar:../dependencies/*;

#REM call the java VM, e.g, 
$JAVA -cp $BASE_CP HttpServer -p 8081 -s spoms2022 -t ../spoms_security/ -c HTTPServer/src/main/java/www

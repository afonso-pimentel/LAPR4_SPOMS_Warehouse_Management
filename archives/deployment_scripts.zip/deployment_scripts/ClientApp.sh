#!/usr/bin/env bash
export JAVA=~/java17/jdk-17.0.2/bin/java

#REM set the class path,
#REM assumes the build was executed with maven copy-dependencies
export BASE_CP=./AllApps/UserConsole/base.app.user.console-1.4.0-SNAPSHOT.jar:./AllApps/dependencies/*;

#REM call the java VM, e.g, 
$JAVA -cp $BASE_CP eapli.base.app.user.console.BaseUserApp -p 9991 -a 10.8.0.80 -t AllApps/spoms_security/ -s spoms2022

#!/bin/bash

netstat -tulpn | grep LISTEN

